module HQP( 
    module HQP.QOp,           -- public QOp API (syntax + helpers; semantics not re-exported)
    module HQP.PrettyPrint
  ) where

import HQP.QOp
import HQP.PrettyPrint
