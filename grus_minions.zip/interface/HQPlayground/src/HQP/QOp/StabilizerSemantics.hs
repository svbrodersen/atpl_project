module HQP.QOp.StabilizerSemantics where

